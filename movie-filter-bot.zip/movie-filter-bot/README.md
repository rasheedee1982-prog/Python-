# 🎬 Telegram Auto Filter Movie Bot

A powerful Telegram bot that automatically filters and serves movie files from your index.

## ✨ Features

- 🔍 **Smart Fuzzy Search** — finds movies even with typos or partial names
- 📄 **Pagination** — 10 results per page with Prev/Next navigation
- 🎬 **Auto Filter** — works in groups AND private chat
- 👆 **Click to Get File** — one click delivers the file instantly
- 👑 **Admin Panel** — index files by forwarding them
- 📊 **Stats Command** — track files, users, groups
- 📢 **Broadcast** — message all users at once

---

## 🗂️ Project Structure

```
movie-filter-bot/
├── bot.py              ← Main entry point
├── config.py           ← Configuration & settings
├── database.py         ← MongoDB operations
├── plugins/
│   ├── start.py        ← /start, /help, /stats
│   ├── index.py        ← File indexing (admin)
│   ├── auto_filter.py  ← Auto search handler
│   ├── callbacks.py    ← Button press handler
│   └── admin.py        ← Admin commands
├── utils/
│   └── helpers.py      ← Fuzzy search, formatting
├── requirements.txt
├── Procfile            ← For Railway/Heroku
├── render.yaml         ← For Render
├── railway.json        ← For Railway
└── .env.example        ← Environment variables template
```

---

## 🚀 Deployment

### Option 1: Railway

1. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
2. Upload/push this folder to a GitHub repo
3. Add environment variables in Railway dashboard:
   - `BOT_TOKEN` — your bot token
   - `MONGO_URI` — MongoDB Atlas connection string
   - `ADMINS` — your Telegram user ID
4. Railway auto-detects `railway.json` and starts the bot!

### Option 2: Render

1. Go to [render.com](https://render.com) → New → Worker
2. Connect your GitHub repo
3. Render uses `render.yaml` automatically
4. Set secret env vars in Render dashboard:
   - `MONGO_URI`
   - `ADMINS`

### Option 3: Local / VPS

```bash
# Clone / copy project
cd movie-filter-bot

# Install dependencies
pip install -r requirements.txt

# Copy and edit environment file
cp .env.example .env
nano .env   # Fill in your values

# Run the bot
python bot.py
```

---

## ⚙️ Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `BOT_TOKEN` | ✅ | Your Telegram bot token from @BotFather |
| `MONGO_URI` | ✅ | MongoDB connection string (Atlas free tier) |
| `DB_NAME` | ❌ | Database name (default: `movie_filter_bot`) |
| `ADMINS` | ✅ | Your Telegram user ID(s), space-separated |
| `LOG_CHANNEL` | ❌ | Channel ID to log new file indexes |
| `FORCE_SUB_CHANNEL` | ❌ | Force users to join a channel |

---

## 📖 Usage

### For Users
1. Add the bot to your group
2. Type any movie name — bot auto-replies with results
3. Click any result button → file is sent instantly

### For Admins
| Command | Description |
|---------|-------------|
| Forward a file | Indexes the file automatically |
| `/stats` | Show total files, users, groups |
| `/search <name>` | Manual search |
| `/broadcast <msg>` | Send message to all users |
| `/delete <file_id>` | Remove a file from index |
| `/deleteall` | Wipe entire file index |

---

## 🛢️ MongoDB Setup (Free)

1. Go to [mongodb.com/atlas](https://mongodb.com/atlas) → Create free cluster
2. Create a database user
3. Whitelist IP `0.0.0.0/0` (allow all)
4. Copy the connection string and set as `MONGO_URI`

---

## 🤖 Get Your Telegram User ID

Message [@userinfobot](https://t.me/userinfobot) on Telegram — it will reply with your user ID.
Set this as `ADMINS` in your `.env` file.
