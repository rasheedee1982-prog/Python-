import os
from dotenv import load_dotenv

load_dotenv()

# ─────────────────────────────────────────────
#  BOT CONFIGURATION
# ─────────────────────────────────────────────

BOT_TOKEN = os.environ.get("BOT_TOKEN", "8166863529:AAFL90trWE0g53Fzq667CDpLbi6kBob7L58")

# MongoDB
MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017")
DB_NAME   = os.environ.get("DB_NAME", "movie_filter_bot")

# Admins (space-separated Telegram user IDs)
ADMINS = [int(x) for x in os.environ.get("ADMINS", "0").split() if x.strip().isdigit()]

# Optional log channel (set to your channel id e.g. -100xxxxxxxxxx)
LOG_CHANNEL = int(os.environ.get("LOG_CHANNEL", "0"))

# Results per page for pagination
RESULTS_PER_PAGE = 10

# Bot start message
START_MSG = """
🎬 <b>Welcome to Movie Filter Bot!</b>

📌 <b>How to use:</b>
• Just send any movie name in the group or here
• I'll search and show you all available files
• Click on a result to get the file instantly

⚙️ <b>Admin Commands:</b>
• Forward any file to me to <b>index it</b>
• /index — Index all files from a channel
• /stats — Show database statistics
• /delete — Delete a file from index
• /broadcast — Send message to all users

🔍 <i>Smart fuzzy search — no exact match needed!</i>
"""

# Force subscribe channel (optional, leave empty to disable)
FORCE_SUB_CHANNEL = os.environ.get("FORCE_SUB_CHANNEL", "")
