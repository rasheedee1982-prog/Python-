import motor.motor_asyncio
from config import MONGO_URI, DB_NAME
import re

# ─────────────────────────────────────────────
#  DATABASE CONNECTION
# ─────────────────────────────────────────────

client = motor.motor_asyncio.AsyncIOMotorClient(MONGO_URI)
db     = client[DB_NAME]

files_col = db["files"]
users_col = db["users"]
groups_col = db["groups"]


# ─────────────────────────────────────────────
#  INDEX CREATION
# ─────────────────────────────────────────────

async def create_indexes():
    await files_col.create_index("file_name")
    await files_col.create_index("file_id", unique=True)
    await users_col.create_index("user_id", unique=True)
    await groups_col.create_index("group_id", unique=True)


# ─────────────────────────────────────────────
#  FILE OPERATIONS
# ─────────────────────────────────────────────

async def save_file(file_data: dict):
    """Save a file to the database. Returns True if new, False if duplicate."""
    try:
        await files_col.insert_one(file_data)
        return True
    except Exception:
        return False


async def get_files(query: str, page: int = 1, per_page: int = 10):
    """
    Search files using regex (case-insensitive) with fuzzy token support.
    Returns (files_list, total_count).
    """
    # Build a flexible regex: each word can match anywhere
    words = re.findall(r'\w+', query)
    if not words:
        return [], 0

    # Each word must appear somewhere in the file_name (flexible order)
    pattern_parts = [f'(?=.*{re.escape(w)})' for w in words]
    pattern = ''.join(pattern_parts)

    regex_query = {"file_name": {"$regex": pattern, "$options": "i"}}

    total = await files_col.count_documents(regex_query)
    skip  = (page - 1) * per_page

    cursor = files_col.find(regex_query).skip(skip).limit(per_page)
    files  = await cursor.to_list(length=per_page)
    return files, total


async def delete_file(file_id: str):
    result = await files_col.delete_one({"file_id": file_id})
    return result.deleted_count > 0


async def get_file_by_id(file_id: str):
    return await files_col.find_one({"file_id": file_id})


async def get_stats():
    total_files  = await files_col.count_documents({})
    total_users  = await users_col.count_documents({})
    total_groups = await groups_col.count_documents({})
    return total_files, total_users, total_groups


# ─────────────────────────────────────────────
#  USER OPERATIONS
# ─────────────────────────────────────────────

async def save_user(user_id: int, full_name: str, username: str = None):
    await users_col.update_one(
        {"user_id": user_id},
        {"$set": {"user_id": user_id, "full_name": full_name, "username": username}},
        upsert=True
    )


async def get_all_users():
    cursor = users_col.find({}, {"user_id": 1})
    return [doc["user_id"] async for doc in cursor]


# ─────────────────────────────────────────────
#  GROUP OPERATIONS
# ─────────────────────────────────────────────

async def save_group(group_id: int, title: str):
    await groups_col.update_one(
        {"group_id": group_id},
        {"$set": {"group_id": group_id, "title": title}},
        upsert=True
    )
