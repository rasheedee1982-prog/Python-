import re
import math
from rapidfuzz import fuzz


def clean_name(name: str) -> str:
    """Remove common file extensions and extra symbols."""
    name = re.sub(r'\.(mkv|mp4|avi|mov|flv|wmv|webm|m4v|ts|3gp)$', '', name, flags=re.IGNORECASE)
    name = re.sub(r'[\[\](){}|_]', ' ', name)
    name = re.sub(r'\s+', ' ', name).strip()
    return name


def get_size_str(size_bytes: int) -> str:
    """Convert bytes to human-readable size."""
    if not size_bytes:
        return "Unknown"
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def fuzzy_score(query: str, name: str) -> int:
    """Calculate fuzzy match score between query and file name."""
    q = query.lower()
    n = name.lower()
    return max(
        fuzz.token_set_ratio(q, n),
        fuzz.partial_ratio(q, n),
        fuzz.token_sort_ratio(q, n)
    )


def rank_results(query: str, files: list) -> list:
    """Sort results by fuzzy relevance score (highest first)."""
    scored = []
    for f in files:
        name  = clean_name(f.get("file_name", ""))
        score = fuzzy_score(query, name)
        scored.append((score, f))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [f for _, f in scored]


def total_pages(total: int, per_page: int) -> int:
    return math.ceil(total / per_page) if total > 0 else 1


def emoji_for_type(file_type: str) -> str:
    mapping = {
        "video":    "🎬",
        "document": "📄",
        "audio":    "🎵",
        "photo":    "🖼️",
    }
    return mapping.get(file_type, "📁")
