from telegram import Update
from telegram.ext import ContextTypes
from database import get_all_users, delete_file, get_files
from config import ADMINS
import asyncio


async def broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id not in ADMINS:
        return await update.message.reply_text("❌ Admins only!")

    if not context.args:
        return await update.message.reply_text(
            "Usage: /broadcast <message>\n"
            "Example: /broadcast Hello everyone!"
        )

    text = " ".join(context.args)
    users = await get_all_users()

    sent, failed = 0, 0
    prog_msg = await update.message.reply_text(f"📤 Broadcasting to {len(users)} users...")

    for uid in users:
        try:
            await context.bot.send_message(uid, text, parse_mode="HTML")
            sent += 1
        except Exception:
            failed += 1
        await asyncio.sleep(0.05)  # Rate limit

    await prog_msg.edit_text(
        f"✅ Broadcast complete!\n"
        f"✔️ Sent: {sent}\n"
        f"❌ Failed: {failed}"
    )


async def delete_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id not in ADMINS:
        return await update.message.reply_text("❌ Admins only!")

    if not context.args:
        return await update.message.reply_text(
            "Usage: /delete <file_id>\n"
            "Get file_id by searching and checking callback data."
        )

    file_id = context.args[0]
    deleted = await delete_file(file_id)

    if deleted:
        await update.message.reply_text("✅ File deleted from index!")
    else:
        await update.message.reply_text("❌ File not found!")


async def deleteall_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id not in ADMINS:
        return await update.message.reply_text("❌ Admins only!")

    from database import files_col
    result = await files_col.delete_many({})
    await update.message.reply_text(
        f"🗑️ Deleted <b>{result.deleted_count}</b> files from index.",
        parse_mode="HTML"
    )


async def search_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manual search via /search <query>"""
    if not context.args:
        return await update.message.reply_text("Usage: /search <movie name>")

    query = " ".join(context.args)
    # Reuse the auto_filter logic
    from plugins.auto_filter import auto_filter
    update.message.text = query
    await auto_filter(update, context)
