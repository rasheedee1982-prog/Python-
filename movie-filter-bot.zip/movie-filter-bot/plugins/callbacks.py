from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import get_file_by_id, get_files
from utils.helpers import clean_name, get_size_str, rank_results, total_pages, emoji_for_type
from config import RESULTS_PER_PAGE


def build_results_keyboard(files: list, page: int, total: int, query: str) -> InlineKeyboardMarkup:
    buttons = []
    pages   = total_pages(total, RESULTS_PER_PAGE)

    for f in files:
        name  = clean_name(f.get("file_name", "Unknown"))
        ftype = f.get("file_type", "document")
        size  = get_size_str(f.get("file_size", 0))
        emoji = emoji_for_type(ftype)
        label = f"{emoji} {name[:45]} [{size}]"
        buttons.append([
            InlineKeyboardButton(label, callback_data=f"getfile|{f['file_id']}")
        ])

    nav = []
    if page > 1:
        nav.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"page|{page-1}|{query}"))
    nav.append(InlineKeyboardButton(f"📄 {page}/{pages}", callback_data="noop"))
    if page < pages:
        nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"page|{page+1}|{query}"))
    if nav:
        buttons.append(nav)

    buttons.append([InlineKeyboardButton("🔄 Refresh", callback_data=f"page|{page}|{query}")])
    return InlineKeyboardMarkup(buttons)


async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query_obj = update.callback_query
    await query_obj.answer()

    data = query_obj.data
    user = update.effective_user
    chat = update.effective_chat

    # ── No-op button (page indicator) ──────────────────────────
    if data == "noop":
        return

    # ── Get File ────────────────────────────────────────────────
    if data.startswith("getfile|"):
        file_id = data.split("|", 1)[1]
        file_doc = await get_file_by_id(file_id)

        if not file_doc:
            await query_obj.answer("❌ File not found in database!", show_alert=True)
            return

        file_name = file_doc.get("file_name", "Unknown")
        file_type = file_doc.get("file_type", "document")
        size_str  = get_size_str(file_doc.get("file_size", 0))
        caption   = (
            f"🎬 <b>{clean_name(file_name)}</b>\n"
            f"📦 Size: {size_str}\n"
            f"📂 Type: {file_type.capitalize()}\n\n"
            f"<i>@{context.bot.username}</i>"
        )

        try:
            # Send file directly in the same chat
            if file_type == "video":
                await context.bot.send_video(
                    chat_id=chat.id,
                    video=file_id,
                    caption=caption,
                    parse_mode="HTML"
                )
            elif file_type == "audio":
                await context.bot.send_audio(
                    chat_id=chat.id,
                    audio=file_id,
                    caption=caption,
                    parse_mode="HTML"
                )
            else:
                await context.bot.send_document(
                    chat_id=chat.id,
                    document=file_id,
                    caption=caption,
                    parse_mode="HTML"
                )
        except Exception as e:
            await query_obj.answer(f"❌ Error sending file: {str(e)[:50]}", show_alert=True)

    # ── Pagination ──────────────────────────────────────────────
    elif data.startswith("page|"):
        parts    = data.split("|", 2)
        new_page = int(parts[1])
        search_q = parts[2] if len(parts) > 2 else ""

        files, total = await get_files(search_q, page=new_page, per_page=RESULTS_PER_PAGE)
        files = rank_results(search_q, files)

        if not files:
            await query_obj.answer("No more results!", show_alert=True)
            return

        pages = total_pages(total, RESULTS_PER_PAGE)
        text  = (
            f"🔍 <b>Results for:</b> <i>{search_q}</i>\n"
            f"📊 Found <b>{total}</b> file(s) • Page <b>{new_page}/{pages}</b>\n\n"
            f"👇 <i>Click a file to receive it instantly</i>"
        )

        keyboard = build_results_keyboard(files, page=new_page, total=total, query=search_q)

        try:
            await query_obj.edit_message_text(
                text,
                parse_mode="HTML",
                reply_markup=keyboard
            )
        except Exception:
            pass
