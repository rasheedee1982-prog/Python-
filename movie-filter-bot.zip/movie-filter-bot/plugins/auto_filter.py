from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import get_files, save_user, save_group
from utils.helpers import clean_name, get_size_str, rank_results, total_pages, emoji_for_type
from config import RESULTS_PER_PAGE
import re


def build_results_keyboard(files: list, page: int, total: int, query: str) -> InlineKeyboardMarkup:
    """Build inline keyboard with file buttons + pagination."""
    buttons = []
    per_page = RESULTS_PER_PAGE
    pages    = total_pages(total, per_page)

    for f in files:
        name  = clean_name(f.get("file_name", "Unknown"))
        ftype = f.get("file_type", "document")
        size  = get_size_str(f.get("file_size", 0))
        emoji = emoji_for_type(ftype)

        label = f"{emoji} {name[:45]} [{size}]"
        # Callback data: "getfile|<file_id>"
        buttons.append([
            InlineKeyboardButton(label, callback_data=f"getfile|{f['file_id']}")
        ])

    # Pagination row
    nav = []
    if page > 1:
        nav.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"page|{page-1}|{query}"))

    nav.append(InlineKeyboardButton(f"📄 {page}/{pages}", callback_data="noop"))

    if page < pages:
        nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"page|{page+1}|{query}"))

    if nav:
        buttons.append(nav)

    buttons.append([InlineKeyboardButton("🔄 Refresh", callback_data=f"page|{page}|{query}")])
    return InlineKeyboardMarkup(buttons)


async def auto_filter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Main auto-filter handler: triggers on text messages."""
    msg  = update.message
    user = update.effective_user
    chat = update.effective_chat

    if not msg or not msg.text:
        return

    query = msg.text.strip()

    # Skip commands
    if query.startswith("/"):
        return

    # Skip very short queries
    if len(query) < 2:
        return

    # Save user & group
    await save_user(user.id, user.full_name, user.username)
    if chat.type in ("group", "supergroup"):
        await save_group(chat.id, chat.title or "")

    # Search database
    files, total = await get_files(query, page=1, per_page=RESULTS_PER_PAGE)

    if not files:
        # Try fuzzy fallback with shorter words
        short_query = " ".join(re.findall(r'\w+', query)[:3])
        files, total = await get_files(short_query, page=1, per_page=RESULTS_PER_PAGE)

    if not files:
        await msg.reply_text(
            f"❌ <b>No results found for:</b> <i>{query}</i>\n\n"
            "💡 Try a shorter or different keyword.",
            parse_mode="HTML"
        )
        return

    # Rank by fuzzy score
    files = rank_results(query, files)

    pages = total_pages(total, RESULTS_PER_PAGE)
    text  = (
        f"🔍 <b>Results for:</b> <i>{query}</i>\n"
        f"📊 Found <b>{total}</b> file(s) • Page <b>1/{pages}</b>\n\n"
        f"👇 <i>Click a file to receive it instantly</i>"
    )

    keyboard = build_results_keyboard(files, page=1, total=total, query=query)

    # Store search context in bot_data for pagination
    search_key = f"search_{chat.id}_{user.id}"
    context.bot_data[search_key] = {"query": query, "total": total}

    await msg.reply_text(text, parse_mode="HTML", reply_markup=keyboard)
