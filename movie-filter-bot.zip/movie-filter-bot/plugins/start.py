from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import save_user, save_group, get_stats
from config import START_MSG, ADMINS
import html


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    await save_user(user.id, user.full_name, user.username)

    await update.message.reply_text(
        START_MSG,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("➕ Add me to Group", url=f"https://t.me/{context.bot.username}?startgroup=true"),
                InlineKeyboardButton("🔍 Search", switch_inline_query_current_chat="")
            ]
        ])
    )


async def stats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id not in ADMINS:
        return await update.message.reply_text("❌ Admins only!")

    total_files, total_users, total_groups = await get_stats()
    await update.message.reply_text(
        f"📊 <b>Bot Statistics</b>\n\n"
        f"🎬 Total Files: <b>{total_files:,}</b>\n"
        f"👥 Total Users: <b>{total_users:,}</b>\n"
        f"🏘️ Total Groups: <b>{total_groups:,}</b>",
        parse_mode="HTML"
    )


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📌 <b>Help Guide</b>\n\n"
        "<b>For Users:</b>\n"
        "• Send any movie/file name — I'll search automatically\n"
        "• Click on results to get the file\n\n"
        "<b>For Admins:</b>\n"
        "• Forward any file to index it\n"
        "• /stats — View database stats\n"
        "• /broadcast &lt;msg&gt; — Broadcast message\n"
        "• /deleteall — Wipe all indexed files\n\n"
        "🔍 <i>Fuzzy search enabled — typos are OK!</i>",
        parse_mode="HTML"
    )
