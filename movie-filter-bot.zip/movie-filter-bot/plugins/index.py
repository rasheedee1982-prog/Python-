from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import save_file, get_stats
from utils.helpers import clean_name, get_size_str
from config import ADMINS, LOG_CHANNEL
import time


async def index_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle forwarded or sent files — index them into DB."""
    user = update.effective_user

    # Only admins can index
    if user.id not in ADMINS:
        return

    msg = update.message

    # Determine file type
    file_obj  = None
    file_type = None
    file_name = None
    file_size = 0

    if msg.document:
        file_obj  = msg.document
        file_type = "document"
        file_name = file_obj.file_name or "Unknown"
        file_size = file_obj.file_size or 0

    elif msg.video:
        file_obj  = msg.video
        file_type = "video"
        file_name = (
            msg.video.file_name
            or (msg.caption and msg.caption.strip())
            or f"video_{int(time.time())}"
        )
        file_size = file_obj.file_size or 0

    elif msg.audio:
        file_obj  = msg.audio
        file_type = "audio"
        file_name = file_obj.title or file_obj.file_name or "Unknown"
        file_size = file_obj.file_size or 0

    else:
        return  # Not a supported file type

    clean = clean_name(file_name)

    file_data = {
        "file_id":   file_obj.file_id,
        "file_name": file_name,
        "clean_name": clean,
        "file_type": file_type,
        "file_size": file_size,
        "caption":   msg.caption or "",
    }

    saved = await save_file(file_data)

    if saved:
        reply = (
            f"✅ <b>File Indexed!</b>\n\n"
            f"📁 <b>Name:</b> {file_name}\n"
            f"📦 <b>Size:</b> {get_size_str(file_size)}\n"
            f"🗂️ <b>Type:</b> {file_type.capitalize()}"
        )
        # Log to log channel if configured
        if LOG_CHANNEL:
            try:
                await context.bot.send_message(
                    LOG_CHANNEL,
                    f"📥 New file indexed by {user.mention_html()}\n"
                    f"📁 {file_name}\n"
                    f"📦 {get_size_str(file_size)}",
                    parse_mode="HTML"
                )
            except Exception:
                pass
    else:
        reply = f"⚠️ <b>Already exists:</b> {file_name}"

    await msg.reply_text(reply, parse_mode="HTML")
