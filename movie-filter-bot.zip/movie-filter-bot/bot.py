import asyncio
import logging
import sys

from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
)

from config import BOT_TOKEN
from database import create_indexes

# ── Plugins ────────────────────────────────────────────────────
from plugins.start       import start, stats_cmd, help_cmd
from plugins.index       import index_file
from plugins.auto_filter import auto_filter
from plugins.callbacks   import handle_callback
from plugins.admin       import broadcast, delete_cmd, deleteall_cmd, search_cmd

# ── Logging ────────────────────────────────────────────────────
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
    stream=sys.stdout
)
logger = logging.getLogger(__name__)


async def post_init(app: Application):
    """Run after bot is initialized."""
    await create_indexes()
    logger.info("✅ Database indexes created.")
    bot_info = await app.bot.get_me()
    logger.info(f"🤖 Bot started: @{bot_info.username}")


def main():
    app = (
        Application.builder()
        .token(BOT_TOKEN)
        .post_init(post_init)
        .build()
    )

    # ── Command Handlers ───────────────────────────────────────
    app.add_handler(CommandHandler("start",       start))
    app.add_handler(CommandHandler("help",        help_cmd))
    app.add_handler(CommandHandler("stats",       stats_cmd))
    app.add_handler(CommandHandler("broadcast",   broadcast))
    app.add_handler(CommandHandler("delete",      delete_cmd))
    app.add_handler(CommandHandler("deleteall",   deleteall_cmd))
    app.add_handler(CommandHandler("search",      search_cmd))

    # ── File Indexing (admins forward files) ──────────────────
    app.add_handler(MessageHandler(
        filters.Document.ALL | filters.VIDEO | filters.AUDIO,
        index_file
    ))

    # ── Auto Filter (text messages in groups & private) ───────
    app.add_handler(MessageHandler(
        (filters.TEXT & ~filters.COMMAND) &
        (filters.ChatType.GROUPS | filters.ChatType.PRIVATE),
        auto_filter
    ))

    # ── Callback Queries (button presses) ─────────────────────
    app.add_handler(CallbackQueryHandler(handle_callback))

    # ── Start Polling ─────────────────────────────────────────
    logger.info("🚀 Bot is running...")
    app.run_polling(
        allowed_updates=Update.ALL_TYPES,
        drop_pending_updates=True
    )


if __name__ == "__main__":
    main()
